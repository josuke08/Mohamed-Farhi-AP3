package com.example.atelier3;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Atelier3ApplicationTests {

    @Test
    void contextLoads() {
    }

}

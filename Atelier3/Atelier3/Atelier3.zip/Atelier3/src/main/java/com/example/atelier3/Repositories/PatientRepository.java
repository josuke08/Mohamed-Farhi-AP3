package com.example.atelier3.Repositories;

import com.example.atelier3.Entites.Patient;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PatientRepository extends JpaRepository<Patient, Long> {

}
